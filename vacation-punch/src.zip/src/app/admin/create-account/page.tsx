
import CreateEmployeeClient from "./ui";
import { requirePrivilegedOrRedirect } from "@/lib/privilgedAuth";

export const dynamic = "force-dynamic";

export default async function Page() {
  await requirePrivilegedOrRedirect();
  return <CreateEmployeeClient />;
}