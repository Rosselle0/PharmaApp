"use client";

import { useEffect, useMemo, useState, Suspense } from "react";
import { useRouter } from "next/navigation";
import { supabaseBrowser } from "@/lib/supabase/browser";
import KioskSidebar from "@/components/KioskSidebar";
import "./kiosk.css";

type ApiActif = {
  employeeId: string;
  name: string;
  state: "WORKING" | "BREAK" | "LUNCH" | "LEFT";
  minutes: number;
};

type ActiveRow = {
  name: string;
  status: "GREEN" | "YELLOW" | "RED" | "GRAY";
  time: string;
};

type PunchState = "OUT" | "IN" | "ON_BREAK" | "ON_LUNCH";

type PunchAction =
  | "CLOCK_IN"
  | "CLOCK_OUT"
  | "BREAK_START"
  | "BREAK_END"
  | "LUNCH_START"
  | "LUNCH_END";

type PunchStatus = {
  state: PunchState;
  breakDone: boolean;
  lunchDone: boolean;
  workMs: number;
  breakMs: number;
  lunchMs: number;
  fetchedAt: string;
};

const PIN_LEN = 4;

type KioskClientProps = {
  isAdminLogged: boolean;
  isManagerLogged: boolean;
  privilegedName?: string;
  privilegedCode?: string;
};

export default function KioskClient({
  isAdminLogged,
  isManagerLogged,
  privilegedName,
  privilegedCode,
}: KioskClientProps) {
  const router = useRouter();
  const supabase = supabaseBrowser();

  const isPrivilegedLogged = isAdminLogged || isManagerLogged;

  const [employeeCodeConfirmed, setEmployeeCodeConfirmed] = useState<string | null>(null);
  const [employeeCode, setEmployeeCode] = useState("");
  const [employeeLogged, setEmployeeLogged] = useState(false);
  const [employeeName, setEmployeeName] = useState<string | null>(null);

  const [autoSubmitting, setAutoSubmitting] = useState(false);
  const [blockedCode, setBlockedCode] = useState<string | null>(null);

  const [pinError, setPinError] = useState(false);
  const [pinSuccess, setPinSuccess] = useState(false);
  const [pinFlash, setPinFlash] = useState(false);

  const [kioskRole, setKioskRole] = useState<string | null>(null);

  const [showAdminModal, setShowAdminModal] = useState(false);
  const [adminEmail, setAdminEmail] = useState("");
  const [adminPassword, setAdminPassword] = useState("");
  const [adminError, setAdminError] = useState<string | null>(null);
  const [adminLoading, setAdminLoading] = useState(false);

  const [toast, setToast] = useState<string | null>(null);
  function showToast(msg: string) {
    setToast(msg);
    window.setTimeout(() => setToast(null), 1800);
  }

  const isAnyLogged = isPrivilegedLogged || employeeLogged;

  const employeeCodeClean = employeeCode.replace(/\D/g, "").slice(0, PIN_LEN);

  const canAccessEmployeePages = useMemo(
    () => isPrivilegedLogged || (employeeLogged && employeeCodeClean.length === PIN_LEN),
    [isPrivilegedLogged, employeeLogged, employeeCodeClean]
  );

  const canAccessLogs = useMemo(() => {
    if (isPrivilegedLogged) return true;
    return employeeLogged && (kioskRole === "ADMIN" || kioskRole === "MANAGER");
  }, [isPrivilegedLogged, employeeLogged, kioskRole]);

  const [actifs, setActifs] = useState<ActiveRow[]>([]);
  const [actifsErr, setActifsErr] = useState<string | null>(null);
  const [punchStatus, setPunchStatus] = useState<PunchStatus | null>(null);
  const [punchStateErr, setPunchStateErr] = useState<string | null>(null);
  const [tickNow, setTickNow] = useState(() => Date.now());

  function mapStateToUi(state: string): ActiveRow["status"] {
    const s = String(state || "").toUpperCase();
    if (s === "WORKING" || s === "IN") return "GREEN";
    if (s === "BREAK" || s === "ON_BREAK") return "YELLOW";
    if (s === "LUNCH" || s === "ON_LUNCH") return "YELLOW";
    if (s === "LEFT" || s === "OUT") return "RED";
    return "GRAY";
  }

  function fmtMinutes(min: number) {
    if (!Number.isFinite(min) || min < 0) return "0 min";
    if (min < 60) return `${min} min`;
    const h = Math.floor(min / 60);
    const m = min % 60;
    return `${h}h ${m}m`;
  }


  function formatDuration(ms: number) {
    const totalSeconds = Math.max(0, Math.floor(ms / 1000));
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    return `${hours}h ${String(minutes).padStart(2, "0")}m ${String(seconds).padStart(2, "0")}s`;
  }

  const effectivePunchCode = employeeCodeConfirmed || (employeeLogged ? employeeCodeClean : "") || privilegedCode || "";

  async function loadPunchState() {
    if (!effectivePunchCode || effectivePunchCode.length !== PIN_LEN) {
      setPunchStatus(null);
      setPunchStateErr(null);
      return;
    }

    try {
      setPunchStateErr(null);
      const url = new URL("/api/punch/state", window.location.origin);
      url.searchParams.set("code", effectivePunchCode);
      const res = await fetch(url.toString(), { cache: "no-store" });
      const data = await res.json().catch(() => null);
      if (!res.ok || !data?.ok) {
        setPunchStatus(null);
        setPunchStateErr(data?.error ?? `Erreur (${res.status})`);
        return;
      }
      setPunchStatus({
        state: data.state ?? "OUT",
        breakDone: Boolean(data.breakDone),
        lunchDone: Boolean(data.lunchDone),
        workMs: Number(data.workMs ?? 0),
        breakMs: Number(data.breakMs ?? 0),
        lunchMs: Number(data.lunchMs ?? 0),
        fetchedAt: String(data.fetchedAt ?? new Date().toISOString()),
      });
    } catch {
      setPunchStateErr("Erreur réseau punch.");
    }
  }

  function getDisplayedMs(status: PunchStatus | null, nowMs: number) {
    if (!status) return 0;
    const sinceFetch = Math.max(0, nowMs - new Date(status.fetchedAt).getTime());
    if (status.state === "IN") return status.workMs + sinceFetch;
    if (status.state === "ON_BREAK") return status.breakMs + sinceFetch;
    if (status.state === "ON_LUNCH") return status.lunchMs + sinceFetch;
    return 0;
  }

  async function loadActifs() {
    try {
      setActifsErr(null);
      const params = new URLSearchParams(window.location.search);
      const urlCode = (params.get("code") ?? "").trim();
      const url = urlCode
        ? `/api/kiosk/actifs?code=${encodeURIComponent(urlCode)}`
        : `/api/kiosk/actifs`;
      const res = await fetch(url, { cache: "no-store" });
      const data = await res.json().catch(() => null);
      if (!res.ok || !data?.ok) {
        setActifs([]);
        setActifsErr(data?.error ?? `Erreur (${res.status})`);
        return;
      }
      const apiRows: ApiActif[] = Array.isArray(data.actifs) ? data.actifs : [];
      const uiRows: ActiveRow[] = apiRows.map((r) => ({
        name: r.name,
        status: mapStateToUi(r.state),
        time: fmtMinutes(Number(r.minutes ?? 0)),
      }));
      setActifs(uiRows);
    } catch {
      setActifs([]);
      setActifsErr("Erreur réseau (actifs).");
    }
  }

  async function punch(type: PunchAction) {
    try {
      const code = effectivePunchCode;
      if (!code || code.length !== PIN_LEN) {
        showToast("Code requis pour punch.");
        return;
      }
      const url = new URL("/api/punch", window.location.origin);
      url.searchParams.set("code", code);
      url.searchParams.set("dev", "1");
      const res = await fetch(url.toString(), {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ type }),
      });
      const data = await res.json().catch(() => null);
      if (!res.ok || !data?.ok) {
        showToast(data?.error ?? `Erreur (${res.status})`);
        return;
      }
      showToast(`✅ ${type}`);
      await Promise.all([loadActifs(), loadPunchState()]);
    } catch {
      showToast("Erreur réseau punch.");
    }
  }

  useEffect(() => {
    loadActifs();
    const t = window.setInterval(loadActifs, 5000);
    return () => window.clearInterval(t);
  }, []);

  useEffect(() => {
    if (!isAnyLogged) {
      setPunchStatus(null);
      setPunchStateErr(null);
      return;
    }

    loadPunchState();
    const refresh = window.setInterval(loadPunchState, 15000);
    const tick = window.setInterval(() => setTickNow(Date.now()), 1000);
    return () => {
      window.clearInterval(refresh);
      window.clearInterval(tick);
    };
  }, [isAnyLogged, effectivePunchCode]);

  function maskedPinBoxes(value: string) {
    const digits = value.slice(0, PIN_LEN);
    return Array.from({ length: PIN_LEN }, (_, i) => digits[i] ?? "");
  }

  function saveEmployeeSession(code: string, name: string | null, role: string) {
    const r = String(role ?? "").toUpperCase();
    localStorage.setItem("kiosk_employee_logged", "1");
    localStorage.setItem("kiosk_employee_code", code);
    localStorage.setItem("kiosk_employee_name", name ?? "");
    localStorage.setItem("kiosk_role", r);
  }

  function clearEmployeeSession() {
    localStorage.removeItem("kiosk_employee_logged");
    localStorage.removeItem("kiosk_employee_code");
    localStorage.removeItem("kiosk_employee_name");
    localStorage.removeItem("kiosk_role");
  }

  useEffect(() => {
    const storedRole = (localStorage.getItem("kiosk_role") ?? "").trim();
    const storedLogged = localStorage.getItem("kiosk_employee_logged") === "1";
    const storedCode = (localStorage.getItem("kiosk_employee_code") ?? "").trim();
    const storedName = (localStorage.getItem("kiosk_employee_name") ?? "").trim();

    setKioskRole(storedRole || null);

    if (storedLogged && storedCode) {
      setEmployeeLogged(true);
      setEmployeeCodeConfirmed(storedCode);
      setEmployeeCode(storedCode);
      setEmployeeName(storedName || null);
    }
  }, []);

  useEffect(() => {
    if (isPrivilegedLogged || employeeLogged) return;

    const onKeyDown = (e: KeyboardEvent) => {
      const el = document.activeElement as HTMLElement | null;
      const tag = (el?.tagName ?? "").toLowerCase();
      if (tag === "input" || tag === "textarea" || el?.getAttribute("contenteditable") === "true") return;

      const isDigitKey = e.key >= "0" && e.key <= "9";
      const isNumpadDigit = /^Numpad[0-9]$/.test(e.code);

      if (isDigitKey || isNumpadDigit) {
        e.preventDefault();
        setPinError(false);
        const digit = isNumpadDigit ? e.code.replace("Numpad", "") : e.key;
        setEmployeeCode((p) => (p + digit).replace(/\D/g, "").slice(0, PIN_LEN));
      }

      if (e.key === "Backspace" || e.key === "Delete") {
        e.preventDefault();
        setPinError(false);
        setEmployeeCode((p) => p.slice(0, -1));
      }

      if (e.key === "Escape") {
        e.preventDefault();
        setEmployeeCode("");
        setPinError(false);
      }
    };

    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [isPrivilegedLogged, employeeLogged]);

  useEffect(() => {
    if (isPrivilegedLogged || employeeLogged || autoSubmitting) return;
    const clean = employeeCode.replace(/\D/g, "").slice(0, PIN_LEN);
    if (clean.length !== PIN_LEN || blockedCode === clean) return;
    setAutoSubmitting(true);
    employeeConfirm(clean).finally(() => setAutoSubmitting(false));
  }, [employeeCode, isPrivilegedLogged, employeeLogged, autoSubmitting, blockedCode]);

  async function employeeConfirm(forcedCode?: string) {
    const clean = (forcedCode ?? employeeCode).replace(/\D/g, "").slice(0, PIN_LEN);
    if (clean.length !== PIN_LEN) {
      setPinError(true);
      showToast("Entrez un code valide.");
      setTimeout(() => setPinError(false), 700);
      return;
    }

    const res = await fetch("/api/kiosk/unlock", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ code: clean }),
    });

    if (!res.ok) {
      setPinError(true);
      return;
    }

    const data = await res.json().catch(() => null);
    const roleFromApi = String(data?.employee?.role ?? "EMPLOYEE").toUpperCase();
    const first = data?.employee?.lastName ?? "";
    const displayName = first.trim();

    setPinError(false);
    setPinSuccess(true);
    setPinFlash(true);

    setTimeout(() => setPinFlash(false), 650);
    setTimeout(() => {
      setEmployeeLogged(true);
      setEmployeeCodeConfirmed(clean);
      setEmployeeName(displayName);
      saveEmployeeSession(clean, displayName, roleFromApi);
      setKioskRole(roleFromApi);
      router.replace(`/kiosk?code=${encodeURIComponent(clean)}`);
    }, 650);
  }

  async function employeeLogout() {
    try {
      await fetch("/api/kiosk/logout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        cache: "no-store",
      });
    } catch {
      // ignore
    }

    localStorage.removeItem("kiosk_role");
    localStorage.removeItem("kiosk_employee_logged");
    localStorage.removeItem("kiosk_employee_code");
    localStorage.removeItem("kiosk_employee_name");

    setKioskRole(null);
    setEmployeeLogged(false);
    setEmployeeCodeConfirmed(null);
    setEmployeeName(null);
    setEmployeeCode("");
    setPinError(false);
    setPinSuccess(false);
    setPinFlash(false);
    setAutoSubmitting(false);
    setBlockedCode(null);

    await Promise.all([loadActifs(), loadPunchState()]);
    window.history.replaceState(null, "", "/kiosk");
    router.replace("/kiosk");
    router.refresh();
  }

  async function adminLogin() {
    if (!adminEmail.trim() || adminPassword.length < 6) return;

    setAdminError(null);
    setAdminLoading(true);

    try {
      const res = await supabase.auth.signInWithPassword({
        email: adminEmail.trim(),
        password: adminPassword,
      });

      if (res.error) throw new Error(res.error.message);

      const meRes = await fetch("/api/me", { cache: "no-store" });
      if (!meRes.ok) throw new Error("Failed /api/me");

      const meJson = await meRes.json();
      const role = String(meJson?.user?.role ?? "").toUpperCase();

      if (role !== "ADMIN" && role !== "MANAGER") {
        throw new Error(`Accès refusé. Role=${role || "NONE"}`);
      }

      localStorage.setItem("kiosk_role", role);
      setKioskRole(role);

      clearEmployeeSession();
      setEmployeeLogged(false);
      setEmployeeCodeConfirmed(null);
      setEmployeeName(null);
      setEmployeeCode("");

      router.replace("/kiosk");
      setShowAdminModal(false);
    } catch (err: any) {
      setAdminError(err.message || "Erreur réseau.");
    } finally {
      setAdminLoading(false);
    }
  }

  async function adminLogout() {
    try {
      await fetch("/api/kiosk/logout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        cache: "no-store",
      });
    } catch {
      // ignore
    }

    try {
      await supabase.auth.signOut();
    } catch {
      // ignore
    }

    localStorage.removeItem("kiosk_role");
    localStorage.removeItem("kiosk_employee_logged");
    localStorage.removeItem("kiosk_employee_code");
    localStorage.removeItem("kiosk_employee_name");

    setKioskRole(null);
    setEmployeeLogged(false);
    setEmployeeCodeConfirmed(null);
    setEmployeeName(null);
    setEmployeeCode("");
    setPinError(false);
    setPinSuccess(false);
    setPinFlash(false);
    setAutoSubmitting(false);
    setBlockedCode(null);

    router.replace("/kiosk");
    router.refresh();
  }

  const state: PunchState = punchStatus?.state ?? "OUT";
  const displayedMs = getDisplayedMs(punchStatus, tickNow);
  const timerLabel =
    state === "ON_BREAK"
      ? "En pause"
      : state === "ON_LUNCH"
      ? "En lunch"
      : state === "IN"
      ? "Temps travaillé"
      : "Temps";
  const timerDanger =
    (state === "ON_BREAK" && displayedMs > 15 * 60 * 1000) ||
    (state === "ON_LUNCH" && displayedMs > 30 * 60 * 1000);

  const buttons: {
    key: string;
    label: string;
    action: PunchAction;
    disabled: boolean;
    danger: boolean;
  }[] = [
    {
      key: "IN",
      label: "IN",
      action: "CLOCK_IN",
      disabled: state !== "OUT",
      danger: false,
    },
    {
      key: "BREAK",
      label: state === "ON_BREAK" ? "Back" : "Break",
      action: state === "ON_BREAK" ? "BREAK_END" : "BREAK_START",
      disabled:
        state === "OUT" ||
        state === "ON_LUNCH" ||
        (state === "IN" && Boolean(punchStatus?.breakDone)) ||
        (state !== "IN" && state !== "ON_BREAK"),
      danger: false,
    },
    {
      key: "LUNCH",
      label: state === "ON_LUNCH" ? "Back" : "Lunch",
      action: state === "ON_LUNCH" ? "LUNCH_END" : "LUNCH_START",
      disabled:
        state === "OUT" ||
        state === "ON_BREAK" ||
        (state === "IN" && Boolean(punchStatus?.lunchDone)) ||
        (state !== "IN" && state !== "ON_LUNCH"),
      danger: false,
    },
    {
      key: "OUT",
      label: "OUT",
      action: "CLOCK_OUT",
      disabled: state !== "IN",
      danger: true,
    },
  ];

  return (
    <main className="kiosk-shell">
      <div className="kiosk-frame">
        <Suspense fallback={<div>Loading menu…</div>}>
          <KioskSidebar
            isPrivilegedLogged={isPrivilegedLogged}
            employeeLogged={employeeLogged}
            employeeCode={employeeCode}
          />
        </Suspense>

        <section className="kiosk-center">
          {!isAnyLogged ? (
            <h1 className="kiosk-title">Bienvenue</h1>
          ) : (
            <h1 className="kiosk-title kiosk-titleLogged">
              {isPrivilegedLogged
                ? `Bonjour ${privilegedName || privilegedCode || "Utilisateur"}`
                : `Salut ${employeeName || "Utilisateur"}`}
            </h1>
          )}

          {isAnyLogged && (
            <div className="loggedWrap">
              <div className="loggedBrand">
                <img src="/Logo-ACC.png" alt="Accès Pharma" className="brandLogo" draggable={false} />
              </div>

              <div className="loggedStatus">
                <span className="loggedCheck" aria-hidden="true">✓</span>
                <div className="loggedStatusText">
                  <div className="loggedStatusTitle">Accès autorisé</div>
                  <div className="loggedStatusSub">Session active — vous pouvez naviguer.</div>
                </div>
              </div>
            </div>
          )}

          {!isAnyLogged && (
            <div
              className={[
                "pinWrap",
                pinError ? "pinWrap--error" : "",
                pinSuccess ? "pinWrap--success" : "",
                pinFlash ? "pinWrap--flash" : "",
              ].join(" ")}
            >
              <div className="pinTitle">Entrez votre pin</div>
              <div className="pinBoxes" role="group" aria-label="PIN">
                {maskedPinBoxes(employeeCode).map((ch, idx) => (
                  <div key={idx} className="pinBox">
                    <span className="pinStar">{ch ? "•" : ""}</span>
                  </div>
                ))}
              </div>
              <div className="pinHint">
                {pinError ? <span className="pinOops">Oops! Pin invalide</span> : <span>{"\u00A0"}</span>}
              </div>
            </div>
          )}

          {!isAnyLogged && (
            <>
              <div className="kiosk-pad">
                {["1", "2", "3", "4", "5", "6", "7", "8", "9"].map((d) => (
                  <button
                    key={d}
                    className="kiosk-key"
                    type="button"
                    onClick={() => {
                      setPinError(false);
                      setEmployeeCode((p) => (p + d).replace(/\D/g, "").slice(0, PIN_LEN));
                    }}
                  >
                    {d}
                  </button>
                ))}

                <div className="kiosk-padBottom">
                  <button
                    className="kiosk-key"
                    type="button"
                    onClick={() => {
                      setPinError(false);
                      setEmployeeCode((p) => (p + "0").replace(/\D/g, "").slice(0, PIN_LEN));
                    }}
                  >
                    0
                  </button>

                  <button
                    className="kiosk-key kiosk-keyDanger"
                    type="button"
                    onClick={() => {
                      setEmployeeCode((p) => p.slice(0, -1));
                      setPinError(false);
                    }}
                  >
                    ⌫
                  </button>
                </div>
              </div>

              <div className="kiosk-actions">
                <button
                  className="kiosk-actionBtn"
                  type="button"
                  onClick={() => {
                    setEmployeeCode("");
                    setEmployeeLogged(false);
                    setEmployeeCodeConfirmed(null);
                    setEmployeeName(null);
                    setPinError(false);
                  }}
                >
                  Clear
                </button>

                <button
                  className="kiosk-actionBtn kiosk-actionPrimary"
                  type="button"
                  onClick={() => employeeConfirm()}
                >
                  OK
                </button>
              </div>
            </>
          )}

          {(employeeLogged || isPrivilegedLogged) && (
            <div className="punchPanel">
              <div className="punchTitle">Punch</div>

              <div className={`punchTimer ${timerDanger ? "danger" : ""}`}>
                <div className="punchTimerLabel">{timerLabel}</div>
                <div className="punchTimerValue">{formatDuration(displayedMs)}</div>
              </div>

              {punchStateErr && <div className="punchError">{punchStateErr}</div>}

              <div className="punchBtns punchBtnsGrid">
                {buttons.map((btn) => (
                  <button
                    key={btn.key}
                    className={`punchBtn ${btn.danger ? "danger" : ""} ${btn.disabled ? "disabled" : ""}`}
                    type="button"
                    disabled={btn.disabled}
                    onClick={() => punch(btn.action)}
                  >
                    {btn.label}
                  </button>
                ))}
              </div>

              <div style={{ marginTop: 14 }}>
                <button
                  className="kiosk-actionBtn"
                  type="button"
                  onClick={() => {
                    if (isPrivilegedLogged) {
                      adminLogout();
                    } else {
                      employeeLogout();
                    }
                  }}
                >
                  Déconnecter
                </button>
              </div>
            </div>
          )}
        </section>

        <aside className="kiosk-rightCol">
          <div className="adminPanelHead">
            <button
              className="kiosk-adminBtn"
              type="button"
              onClick={() => {
                setAdminError(null);
                setAdminPassword("");
                setShowAdminModal(true);
              }}
            >
              Admin
            </button>
          </div>

          <div className="kiosk-actifsCard">
            <div className="kiosk-actifsTitle">Actifs</div>

            {actifsErr && (
              <div style={{ marginTop: 8, color: "#f04438", fontWeight: 800 }}>
                {actifsErr}
              </div>
            )}

            <div className="kiosk-table">
              <div className="kiosk-row kiosk-head">
                <div>Nom</div>
                <div>Status</div>
                <div>Temps</div>
              </div>

              {actifs.length === 0 ? (
                <>
                  <div className="kiosk-emptyNote">Aucun actif</div>
                  <div className="kiosk-row empty">
                    <div />
                    <div />
                    <div />
                  </div>
                  <div className="kiosk-row empty">
                    <div />
                    <div />
                    <div />
                  </div>
                  <div className="kiosk-row empty">
                    <div />
                    <div />
                    <div />
                  </div>
                </>
              ) : (
                actifs.map((r) => (
                  <div key={r.name} className="kiosk-row">
                    <div className="kiosk-name">{r.name}</div>
                    <div className="kiosk-statusCell">
                      <span className={`kiosk-dot ${r.status}`} aria-hidden="true" />
                    </div>
                    <div className="kiosk-time">{r.time}</div>
                  </div>
                ))
              )}
            </div>
          </div>
        </aside>
      </div>

      {showAdminModal && !isPrivilegedLogged && (
        <div
          className="modal-overlay"
          onMouseDown={(e) => e.target === e.currentTarget && setShowAdminModal(false)}
        >
          <div className="modal-card">
            <div className="modal-head">
              <h2 className="modal-title">Admin</h2>
              <button
                className="ghost"
                type="button"
                onClick={() => setShowAdminModal(false)}
                disabled={adminLoading}
              >
                ✕
              </button>
            </div>

            <p className="modal-sub">Connexion admin (email + mot de passe).</p>

            <label>Email</label>
            <input
              value={adminEmail}
              onChange={(e) => setAdminEmail(e.target.value)}
              disabled={adminLoading}
            />

            <label style={{ marginTop: 10 }}>Mot de passe</label>
            <input
              value={adminPassword}
              type="password"
              onChange={(e) => setAdminPassword(e.target.value)}
              disabled={adminLoading}
              onKeyDown={(e) => {
                if (e.key === "Enter") adminLogin();
              }}
            />

            {adminError && <div className="alert">{adminError}</div>}

            <button
              className="primary"
              onClick={adminLogin}
              disabled={adminLoading || !adminEmail.trim() || adminPassword.length < 6}
            >
              Se connecter
            </button>

            <button
              className="secondary"
              onClick={() => setShowAdminModal(false)}
              disabled={adminLoading}
            >
              Annuler
            </button>
          </div>
        </div>
      )}

      {toast && <div className="kiosk-toast">{toast}</div>}
    </main>
  );
}